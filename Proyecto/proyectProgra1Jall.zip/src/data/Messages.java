package data;

import javax.swing.JOptionPane;
public class Messages{
  //para el boton de los reportes
  public void showMessage(String message){
    JOptionPane.showMessageDialog(null,message);
  }
  
}