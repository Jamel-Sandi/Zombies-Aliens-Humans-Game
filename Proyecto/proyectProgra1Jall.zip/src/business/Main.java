package business;

public class Main {
	public static void main(String args[]) {

		ControllerInicio co = new ControllerInicio();

	}

}
